import React from 'react';
import './ContentBox.css';

function ContentBox ({ view }) {
  function renderContent(){
    switch (view) {
      case 'home':
        return <h2>Welcome to the Home Page</h2>;
      case 'about':
        return <h2>About Us: We are a tech company...</h2>;
      default:
        return <h2>Click a link in the sidebar</h2>;
    }
  };

  return <div className="content">{renderContent()}</div>;
};

export default ContentBox;
