import React from 'react';
import './Footer.css';

function Footer() {
  return (
    <footer className="footer">
      <h1><marquee>This is Footer of my website</marquee></h1>
    </footer>
  );
};

export default Footer;
